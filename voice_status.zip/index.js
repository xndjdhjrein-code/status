// Code Nexus => https://discord.gg/Tpwgkj9gzj

require('dotenv').config();
const { Client, GatewayIntentBits, SlashCommandBuilder, REST, Routes, ActivityType } = require('discord.js');
const { joinVoiceChannel } = require('@discordjs/voice');

const client = new Client({
    intents: [
        GatewayIntentBits.Guilds,
        GatewayIntentBits.GuildMessages,
        GatewayIntentBits.GuildVoiceStates
    ]
});

const commands = [
    new SlashCommandBuilder()
        .setName('status')
        .setDescription('Change the bot status')
        .addStringOption(option =>
            option.setName('type')
                .setDescription('Select the new status')
                .setRequired(true)
                .addChoices(
                    { name: 'Online 🟢', value: 'online' },
                    { name: 'Idle 🟡', value: 'idle' },
                    { name: 'Do Not Disturb 🔴', value: 'dnd' },
                    { name: 'Offline ⚫', value: 'invisible' }
                )
        )
].map(command => command.toJSON());

client.once('ready', async () => {
    console.log(`✅ Bot is online as ${client.user.tag}`);

    const voiceChannelId = process.env.VOICE_CHANNEL_ID;
    if (!voiceChannelId) {
        console.error('❌ VOICE_CHANNEL_ID is not set in the .env file');
    } else {
        try {
            const channel = await client.channels.fetch(voiceChannelId);
            if (channel) {
                joinVoiceChannel({
                    channelId: voiceChannelId,
                    guildId: channel.guild.id,
                    adapterCreator: channel.guild.voiceAdapterCreator
                });
                console.log(`🔊 Bot joined the voice channel: ${channel.name}`);
            }
        } catch (error) {
            console.error('❌ Failed to join the voice channel:', error);
        }
    }

    try {
        console.log('🔃 Registering commands...');
        const rest = new REST({ version: '10' }).setToken(process.env.DISCORD_TOKEN);
        await rest.put(
            Routes.applicationGuildCommands(client.user.id, process.env.GUILD_ID),
            { body: commands }
        );
        console.log('✅ Commands registered successfully!');
    } catch (error) {
        console.error('❌ Error while registering commands:', error);
    }
});

client.on('interactionCreate', async interaction => {
    if (!interaction.isCommand()) return;
    
    if (interaction.commandName === 'status') {
        const requiredRoleId = process.env.ROLE_ID;
        const member = await interaction.guild.members.fetch(interaction.user.id);

        if (!member.roles.cache.has(requiredRoleId)) {
            return interaction.reply({ content: '❌ | You do not have permission to use this command.', ephemeral: false });
        }

        const status = interaction.options.getString('type');

        client.user.setPresence({
            status: status,
            activities: [{ name: 'Code Nexus', type: ActivityType.Watching }]
        });

        await interaction.reply({ content: `✅ | Bot status changed to **${status}**!`, ephemeral: false });
        console.log(`🔄 Bot status changed to: ${status}`);
    }
});

client.login(process.env.DISCORD_TOKEN);

// Code Nexus => https://discord.gg/Tpwgkj9gzj